package Main;


import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import BaseClass.LibGlobal;

import Utils.Excel_Utils;
import Utils.Excel_Utils1;

public class Run extends LibGlobal {
	int count = 0;
	static int respCode = 200;
	static HttpURLConnection huc = null;
	
	
	LibGlobal lb = new LibGlobal();

	@DataProvider
	public Iterator<Object[]> getTestData() {
		ArrayList<Object[]> testData = Excel_Utils.getDataFromexcel();
		return testData.iterator();
	}

	static ExtentTest test;
	static ExtentReports report;

	@Test

	(dataProvider = "getTestData")
	public void PageURLverify(String INDEX, String PageURL, String Title, String Description, String keywords)
			throws Exception {
	
		launchBrowser("chrome");
		
		loadUrl(PageURL);
		List<WebElement> findElements = driver.findElements(By.tagName("h1"));
		System.out.println("count:" +""+findElements.size());
	      Thread.sleep(2000);
	      String h1count = String.valueOf(findElements.size());
     System.out.println(h1count);
		// second parameter

		String Actualtitle = driver.getTitle().toLowerCase();
		System.out.println(Actualtitle + "\t" + " --PAGE TITLE");
		System.out.println(Title + "\t" + "--Excel Data");
		
		if (Actualtitle.equals(Title)) {
			int parseInt = Integer.parseInt(INDEX);
			Excel_Utils.writeinexcel2("PASS", parseInt);
			System.out.println("PASS");
		} else {
			int parseInt = Integer.parseInt(INDEX);
			Excel_Utils.writeinexcel2("FAIL", parseInt);

			Excel_Utils.writeinexcel5(Actualtitle, parseInt);
			System.out.println("FAIL");
 
		}

		// 3 params

		String pageDescription = lb.getPageDescription().toLowerCase();

		System.out.println(pageDescription + "\t" + " --PAGE DESCRIPTION");
		System.out.println(Description + "\t" + "--Excel Data");

		if (pageDescription.equals(Description)) {

			int parseInt = Integer.parseInt(INDEX);
			Excel_Utils.writeinexcel3("PASS", parseInt);
			System.out.println("PASS");

		} else {
			int parseInt = Integer.parseInt(INDEX);
			Excel_Utils.writeinexcel3("FAIL", parseInt);
			Excel_Utils.writeinexcel6(pageDescription, parseInt);
			System.out.println("FAIL");
		}
		

		// 4 params


		String pageKeywords = lb.getPageKeywords().toLowerCase();
		System.out.println(pageKeywords + "\t" + " --PAGE KEYWORDS");
		System.out.println(keywords + "\t" + "--Excel Data");

		if (pageKeywords.equals(keywords)) {
			int parseInt = Integer.parseInt(INDEX);
			Excel_Utils.writeinexcel4("PASS", parseInt);

			System.out.println("PASS");
		} else {
			int parseInt = Integer.parseInt(INDEX);
			Excel_Utils.writeinexcel4("FAIL", parseInt);
			Excel_Utils.writeinexcel7(pageKeywords, parseInt);
			System.out.println("FAIL");

		}
		try {
			SimpleDateFormat dateformet = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
			Date date = new Date();
			String format = dateformet.format(date);
			int parseInt = Integer.parseInt(INDEX);
			Excel_Utils.writeinexcel9(format, parseInt);
			//Excel_Utils1.writeinexcel8(format, parseInt);
			System.out.println(++count + "\t" + "is Row is completed." + "\t" + format);
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Thread.sleep(2000);
		driver.quit();
	}

	
}
